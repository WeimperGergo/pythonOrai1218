import hetedik

hetedik.hetes()
