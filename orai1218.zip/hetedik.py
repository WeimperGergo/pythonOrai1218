import Renszarvas

def beolvas():
    lista = []
    fajlbol = open("Mikulasszan.txt", "r", encoding="utf-8")
    adatokListaja = fajlbol.readlines()
    for i in range(1, len(adatokListaja), 1):
        if not adatokListaja[i].startswith("Santa Claus"):
        # if not ("Santa Claus" in adatokListaja[i]):
            daraboltSor = adatokListaja[i].strip().split('@')
            # print(daraboltSor)
            szarvas = Renszarvas.Renszarvas(daraboltSor[0], daraboltSor[1], daraboltSor[2], daraboltSor[3])
            # print(szarvas)
            lista.append(szarvas)
    fajlbol.close()
    return lista
def hetes():
    # a feladat
    szarvasokListaja = beolvas()
    # b feladat
    for i in szarvasokListaja:
        print(i.kiir())
    #c feladat
    print("Rénszarvasok száma: " + str(len(szarvasokListaja)))
